package l7exercise;


public class Employee extends StaffMember{
   private int age;
   private double salary;

    public Employee() {
    }

    public Employee(int age, double salary) {
        this.age = age;
        this.salary = salary;
    }
   
    
}
