/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package l7exercise;

/**
 *
 * @author k00216207
 */
public abstract class StaffMember {
    
    private String name;
    private String address;
    private String phone;
    
    protected StaffMember(){}
    
    protected StaffMember(String n, String a,String p){
        this.address = a;
        this.name = n;
        this.phone = p;
    }
    public abstract double pay();
    
    public String toString(){return this.address;}
}
