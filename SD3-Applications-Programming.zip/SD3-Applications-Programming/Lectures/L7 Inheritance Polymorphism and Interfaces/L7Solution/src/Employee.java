
public class Employee {
   private int age;
   private double salary;

    public Employee() {
    }

    public Employee(int age, double salary) {
        this.age = age;
        this.salary = salary;
    }
   
    
}
