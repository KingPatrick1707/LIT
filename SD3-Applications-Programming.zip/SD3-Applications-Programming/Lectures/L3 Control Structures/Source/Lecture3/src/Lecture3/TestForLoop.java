package Lecture3;

//application to demonstrate the use of for loops

public class TestForLoop {

	public static void main(String args[]) {

		for (int i = 1; i <= 100; i++) {
			System.out.println(i);
		}

	} //end main

} //end class TestForLoop
