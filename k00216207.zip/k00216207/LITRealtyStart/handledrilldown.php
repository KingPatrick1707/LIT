<?php
include 'header.php';


$id=$_GET['id'];
echo $id;

$sql = "SELECT * from properties WHERE id = '$id'";


//if there was an error in sql
if (!$result = $db->query($sql)) {
    die('There was an error running the query [' . $db->error . ']');
}

//if no row in result set print error
if ($result->num_rows== 0) {
    echo "<p>No propertes matched your search criteria, <a href = \"index.php\">Go Back</a></p>";
      
} 

else {

    






?>
<!--
<img src="images/property/thumbnails/<?php echo $row['photo'] ?>"/>     

<h5><?php  ?></h5>
<h5><?php  ?></h5>
<h5><?php  ?></h5>
<h5><?php  ?></h5>
<h5><?php  ?></h5>
<p><?php  ?></p>
<p><?php  ?></p>
-->