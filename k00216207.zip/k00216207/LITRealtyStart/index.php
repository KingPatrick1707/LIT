<?php 
include 'header.php';
?>       
        <form name="getcriteria" action="handleform.php" method="POST">
            <br>
            <font color="red"> <i>Please Enter Your Search Criteria </i></font>
            <br>
			<label for="EnterLocation">Enter Property Location</label>
			<input type="text" name="EnterLocation" id="EnterLocation"/>
			<br>
			<label for="EnterNumber">Select Price Range</label>
			<select name="PriceRange">
			<option value="Any">'Any'</option>
			<option value="b">€150,000 – €200,000</option>
			<option value="c">€200,000 – €250,000</option>
			<option value="d">€250,000 - €350,000</option>
			<option value="e">€350,000 - €500,000</option>
			</select>
			<br>
            <input type="submit" value="Submit" name="submitbtb" />     
        </form>

<br>
<?php

include 'footer.php';
?>