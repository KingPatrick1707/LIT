
<?php

include 'header.php';

//get conn to DB
include 'dbconnect.php';

$city = $_POST["EnterLocation"];
$price = $_POST["PriceRange"];
//begin to build sql query 
if($price == "Any")
{
	$sql = "SELECT * from properties WHERE city = '$city'";
	
}
if($price == "b")
{
	$sql = "SELECT * from properties WHERE city = '$city'AND price > 150000 AND price < 200000";
	
}
if($price == "c")
{
	$sql = "SELECT * from properties WHERE city = '$city'AND price > 200000 AND price < 250000";
	
}
if($price == "d")
{
	$sql = "SELECT * from properties WHERE city = '$city'AND price > 250000 AND price < 350000";
	
}
if($price == "e")
{
	$sql = "SELECT * from properties WHERE city = '$city'AND price > 350000 AND price < 500000";
	
}


//if there was an error in sql
if (!$result = $db->query($sql)) {
    die('There was an error running the query [' . $db->error . ']');
}

//if no row in result set print error
if ($result->num_rows== 0) {
    echo "<p>No propertes matched your search criteria, <a href = \"index.php\">Go Back</a></p>";
      
} 

else {

    ?>
        
    <table border = "1">
    <thead>
        <tr>
            <th>Street</th>
            <th>Bedrooms</th>
            <th>Bathrooms</th>
            <th>Description</th>
            <th>Photo</th>
            <th>Price</th>
        </tr>
        </thead>
    <tbody>
   
<?php

    //if we have records in result set, iterate over them
    while ($row = $result->fetch_assoc()) {
        
        //get the property IF
        $propID = $row['id']; 
        
?>
    <tr>
        <td><?php echo $row['street'] ?></td>
        <td><?php echo $row['bedrooms'] ?></td>
        <td><?php echo $row['bathrooms'] ?></td>
        <td><?php echo $row['description'] ?></td>
        <td>
            <a href="handledrilldown.php?id=<?php echo $propID ?>">
                <img src="images/property/thumbnails/<?php echo $row['photo'] ?>"/>
            </a>
        </td>
        <td><?php echo "€" . number_format($row['price'], 2); ?></td>
    </tr>
    <?php 
    
        }//end while
    }//end else
    
    ?>

    </tbody>
    </table>
<br>
<?php

include 'footer.php';
?>