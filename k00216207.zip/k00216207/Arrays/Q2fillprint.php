<?php
$marks = array();
$subjectAverages = array("WP"=> 0,"WD"=>0,"ID"=>0,"DV"=>0,"HC"=>0,"PR"=>0);
$studentAverages = array();
$classAverage = 0;

//Step 1 - Fill array with subjects and random marks
fillArray($marks);

//temp step print
tempPrint($marks);

//Step 2 - Add a new row (average) for each subject, containing the average grade obtained in the subject
//findSubjectAverages($marks,$subjectAverages);

//Step 3 - Add a new column (average) for each student, containing their average grade
//studentAverages($marks,$studentAverages);

//Step 4 - Caclculate class average & print out results (including results < 40 shown in red) 
//printArray($marks,$studentAverages,$classAverage,$subjectAverages);

//Step 5 - Print the knumbers of students who fell below the class average and the number of students who fell below average
//analysisOverAverages($classAverage, $studentAverages);

//////////////////////////////////////////////////////////////////////////////////////////
function fillArray(&$marks){
	for($k=1; $k<=10;$k++){
		$studentNumber = "K00". $k;
		$marks[$studentNumber]=array("WP"=> rand(0, 100),"WD"=>rand(0, 100),"ID"=>rand(0, 100),"DV"=>rand(0, 100),"HC"=>rand(0, 100),"PR"=>rand(0, 100));
	}//end for
}//end function fillArray


//////////////////////////////////////////////////////////////////////////////////////////
function tempPrint($marks){
	foreach($marks as $student=>$grades){
		echo "Student: " . $student . "\t";
			foreach($grades as $subject=>$value){
				echo ($subject . " = " .$value. "\t");
			}//end foreach
			echo "<br>";	
	}//end foreach
}//end function tempPrint

