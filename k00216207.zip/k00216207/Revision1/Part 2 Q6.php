<html>
<title>q5</title>
<head></head>
<body>
<?php
if(isset($_GET['EnterNumber'])){
	$word =$_GET['EnterNumber'];
	for	($i = 0; $i < strlen($word); $i++)
	{
		echo substr($word,$i,1). "<br>";
	}
} else {
?>
<form id="form1" name = "form" method="get" action="">
	<p>
		<label for="EnterNumber">EnterWord</label>
		<input type="text" name="EnterNumber" id=="EnterNumber"/>
		
	</p>
	<p>
		<input type="submit" name="button" id="button"/>
	</p>
</form>
<?php } ?>
</body>
</html>