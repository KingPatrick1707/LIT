<?php 

$number =1;
$y =2;
$temp;
while($number < 101)
{
	echo $number;
	$number++ . <br>;
}
//for loop with if statement modulas
?>