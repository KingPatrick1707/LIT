<?php 
for($i =1;$i<100;$i++)
{
	$number = (rand(0,19));
	echo $number;
	if ( $number % 10 == 0)
	{
		echo "<br>";
	}	
}
?>