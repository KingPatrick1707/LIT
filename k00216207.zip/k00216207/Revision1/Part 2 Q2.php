<html>
<title>q2</title>
<head></head>
<body>
<form id="form1" name = "form" method="post" action="">
	<p>
		<label for="EnterNumber">EnterNumber</label>
		<input type="text" name="EnterNumber" id=="EnterNumber"/>
		
	</p>
	<p>
		<input type="submit" name="button" id="button"/>
	</p>
</form>

</body>
</html>
<?php
if(isset($_POST['EnterNumber'])){
	$number =$_POST['EnterNumber'];
	for($i =0;$i<$number;$i++)
	{
		echo $i;	
	}
}
?>