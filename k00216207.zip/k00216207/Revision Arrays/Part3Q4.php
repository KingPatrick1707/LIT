<html><head><title>P3Q4</title></head>
<body>

<?php
$count=0;$count2 =0;
$newArray = array();
while($count <1000)
{
	$newArray($count) = rand(1,30);
	$count++;
}

while($count2 <1000)
{
	$mean +=$newArray($count2)
	$count2++;
}
print_r($newArray);
print_r($mean);


//print_r(array_reverse($a));
//array_sum()
//count();
//sort();
//array_count_values();
//$newArray =array_reverse($numbers);
?>

</body>
</html>


