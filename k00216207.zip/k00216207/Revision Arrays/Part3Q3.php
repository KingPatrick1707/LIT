<html><head><title>Q7</title></head>
<body>

<?php
$numbers= array(1, 8, 2,1, 5, 3,1, 8, 2,1, 5, 3,1, 8, 2,1, 5, 3,9,5);
print_r($numbers);
array_reverse($numbers);
print_r($numbers);
?>

</body>
</html>
