<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>LIT Realty</title>
    </head>
    <body>
        
        
         <img src="imgs/site/LIT_Logo.PNG" width="105" height="106" alt="LIT_Logo"/>
        <font size="25" style="font-family:verdana;">  LIT Realty </font>
        <img src="imgs/site/LIT_Logo.PNG" width="105" height="106" alt="LIT_Logo"/>