<?php 
include 'header.php';
?>       
        <form name="getcriteria" action="handleform.php" method="POST">
            <br>
            <font color="red"> <i>Please Enter Your Search Criteria </i></font>
            <table border="0" cellpadding="5">
               
                <tbody>
                    <tr>
                        <td>Enter Property Location</td>
                        <td><input type="text" name="location" /></td>
                    </tr>
                    <tr>
                        <td>Select Price Range</td>
                        <td><select name="rangeselect">
                                <option value="0">Any</option>
                                <option value="1">€50,000 - €200,000</option>
                                <option value="2">€200,000 - €250,000</option>
                                <option value="3">€250,000 - €350,000</option>
                                <option value="4">€350,000 - €500,000</option>
                                <option value="5">> €500,000</option>
                            </select></td>
                    </tr>
                </tbody>
            </table>
            <br>
            <input type="submit" value="Submit" name="submitbtb" />     
        </form>

<br>
<?php

include 'footer.php';
?>