<?php

$db = new mysqli('localhost', 'sd3user', 'pass', 'litrealty');

if($db->connect_errno > 0){
    die('Unable to connect to database [' . $db->connect_error . ']');
}

?>


