
<?php

include 'header.php';

//get conn to DB
include 'dbconnect.php';

@$location = htmlspecialchars($_POST["location"]);
@$range = htmlspecialchars($_POST["rangeselect"]);

if ($location == null) {
	echo "<br><br>";
	echo "<a href=\"javascript:history.go(-1)\">Search</a>";
	exit;
}

//begin to build sql query
if ($range == "0") {

    $sql = "SELECT * from properties where city = '$location'";
    
}
else if ($range =="1") {
    
    $sql = "SELECT * from properties where city = '$location' and price >= 50000 AND price <= 200000";

}
else if ($range =="2") {
    
    $sql = "SELECT * from properties where city = '$location' and price >= 200000 AND price <= 250000";
}

else if ($range =="3") {
    
    $sql = "SELECT * from properties where city = '$location' and price >=  250000 AND price <= 350000";
}

else if ($range =="4") {
    
    $sql = "SELECT * from properties where city = '$location' and price >= 350000 AND price <= 500000";
}

else if ($range =="5") {
    
    $sql = "SELECT * from properties where city = '$location' and price >= 500000";
}

//if there was an error in sql
if (!$result = $db->query($sql)) {
    die('There was an error running the query [' . $db->error . ']');
}

//if no row in result set print error
if ($result->num_rows== 0) {
    echo "<p>No propertes matched your search criteria, <a href = \"index.php\">Go Back</a></p>";
      
} 

else {
    echo "<br>There were " .$result->num_rows .  " properties found in " . $location;
    ?>
        
    <table border = "1">
    <thead>
        <tr>
            <th>Street</th>
            <th>Bedrooms</th>
            <th>Bathrooms</th>
            <th>Description</th>
            <th>Photo</th>
            <th>Price</th>
        </tr>
        </thead>
    <tbody>
   
<?php

    //if we have records in result set, iterate over them
    while ($row = $result->fetch_assoc()) {
        
        //get the property IF
        $propID = $row['id']; 
        
?>
    <tr>
        <td><?php echo $row['street'] ?></td>
        <td><?php echo $row['bedrooms'] ?></td>
        <td><?php echo $row['bathrooms'] ?></td>
        <td><?php echo $row['description'] ?></td>
        <td>
            <a href="handledrilldown.php?id=<?php echo $propID ?>">
                <img src="imgs/property/thumbnails/<?php echo $row['photo'] ?>"/>
            </a>
        </td>
        <td><?php echo "€" . number_format($row['price'], 2); ?></td>
    </tr>
    <?php 
    
        }//end while
    }//end else
    
    ?>

    </tbody>
    </table>
<br>
<?php

include 'footer.php';
?>