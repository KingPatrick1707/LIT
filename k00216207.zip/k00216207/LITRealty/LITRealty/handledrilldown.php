<?php

include 'header.php';

//get conn to DB
include 'dbconnect.php';

$propertyid = htmlspecialchars($_GET["id"]);


$sql = "SELECT agents.name, agents.phone, agents.fax, agents.email, properties.id, properties.street, properties.bedrooms, properties.bathrooms, properties.description, properties.squarefeet, properties.photo, properties.price FROM properties INNER JOIN agents ON agents.agentId = properties.agentId WHERE properties.id= $propertyid";

//if there was an error in sql
if (!$result = $db->query($sql)) {
    die('There was an error running the query [' . $db->error . ']');
}

//get results
$row = $result->fetch_assoc();

if ($result->num_rows == 0) {
    echo "<p>No propertes matched your search criteria, <a href = \"index.php\">Go Back</a></p>";
    exit();
      
} 

?>
<br><br>
<table border="0" width="650">
    <tbody>
        <tr>
            <td>Street: <?php echo $row['street'] ?></td>
            <td rowspan="5" align="center" ><img src="imgs/property/full/<?php echo $row['photo'] ?>"   /></td>
        </tr>
        <tr>
            <td>Bedrooms: <?php echo $row['bedrooms'] ?></td>
           
        </tr>
        <tr>
            <td>Bathrooms: <?php echo $row['bathrooms'] ?></td>
    
        </tr>
        <tr>
            <td>Square Feet: <?php echo $row['squarefeet'] ?></td>
     
        </tr>
        <tr>
            <td>Price: <?php echo "€" . number_format($row['price'], 2); ?></td>
        
        </tr>
    </tbody>
</table>

<h3>Agents Contact Details</h3>
<table width = "600" border="0">
   <tbody>
        <tr>
            <td><b><i>Name:</i> </b></td>
            <td><?php echo $row['name'] ?></td>
            <td><b><i>Phone: </i></b></td>
            <td><?php echo $row['phone'] ?> </td>
            <td><b><i>Fax: </i></b></td>
            <td><?php echo $row['fax'] ?></td>
            <td><b><i>Email: </i></b></td>
            <td><?php echo $row['email'] ?>  </td></td>
        </tr>
    </tbody>
</table>

  

     <br><br>
<?php

include 'footer.php';
?>
     

