#include <cmath>
#include <iomanip>

using namespace std;

template<class ItemType>
struct TreeNode
{
	ItemType info;
	TreeNode* left;
	TreeNode* right;
};
// Assumption: ItemType is a type for which the operators "<"
// and "==" are defined. either an appropriate built-in type or
// a class that overloads these operators.
//needs overloaded > too DFW.


template<class ItemType>
class TreeType {
public:
	TreeType();

	~TreeType();

	bool IsEmpty() const;

	int NumberOfNodes() const;

	void RetrieveItem(ItemType&, bool&) const;

	void InsertItem(ItemType);    //item may be in tree (duplicates OK) DFW

	void DeleteItem(ItemType);
	//   OK for no such node, or multiple ones. Deletes the first it finds. DFW

	void PrintTree() const;        //in order

private:
	TreeNode<ItemType> * root;
};
//*********************************************************
//overloaded <<  function so works with TreeNode.  Added DFW
//Assumption: info member of TreeNode can be handled by cout.
//used by Print member function: cout << *t;
template <class ItemType>
ostream& operator<<(ostream& os, TreeNode<ItemType> tn) {
	os << tn.info << ' ';
	return os;
}



//*********************************************************
//constructor
template<class ItemType>
TreeType<ItemType>::TreeType()
{
	root = NULL;
}

//*********************************************************
//note this is not a member function of TreeType.  
//It can access the data members of struct TreeNode.
template<class ItemType>
int CountNodes(TreeNode<ItemType>* t)
// Post: returns the number of nodes in the tree.
{
	if (t == NULL)
		return 0;
	else
		//this node + #nodes in left + #nodes in right
		return CountNodes(t->left) +
		CountNodes(t->right) + 1;
}

template<class ItemType>
int TreeType<ItemType>::NumberOfNodes() const
// Calls recursive function CountNodes to count the nodes in the tree.
//This public member function can't be recursive because the client
//code would have to have access to the private root as argument.
{
	return CountNodes(root);
}

//*********************************************************
template<class ItemType>
void TreeType<ItemType>::RetrieveItem(ItemType& item, bool& found) const
// Searches tree for item.
// Post: If there is an element someItem whose key matches item's, found
//   is true and item is set to a copy of someItem; otherwise found
//   is false and item is unchanged.
{
	TreeNode<ItemType>* t = root;

	while (t != NULL && t->info != item) //not fallen off nor found item
		if (item < t->info)
			t = t->left;                      // Search left subtree.
		else
			t = t->right;                     // Search right subtree.

	if (t == NULL)                 //unsuccessful search 
		found = false;
	else {		         //successful search 
		item = t->info;	//assumes ItemType can be assigned
		found = true;
	}
}


//*********************************************************
template<class ItemType>
void TreeType<ItemType>::InsertItem(ItemType item)
// Inserts item into tree. 
{
	TreeNode<ItemType>* t = root;
	TreeNode<ItemType>* par = NULL;   //points to parent of t

									  //do an "unsuccessful" search for the place where item belongs
	while (t != NULL) {     //until fall off tree
		par = t;
		if (item < t->info)
			t = t->left;      //go down left
		else
			t = t->right;     //go down right
	}

	//par points to bottom node that new one will be attached to.
	//create and initialize the new node:  t is now NULL since fell off tree. reuse it
	t = new TreeNode<ItemType>;
	t->right = NULL;      //will be a leaf
	t->left = NULL;
	t->info = item;

	if (par == NULL)    //special case of inserting into empty tree
		root = t;
	else if (item < par->info)
		par->left = t;      //bottom node's child pointer points to new node
	else
		par->right = t;
}



//*********************************************************
// search for a node to delete and if found remove it from BST
template<class ItemType>
void TreeType<ItemType>::DeleteItem(ItemType item)
{
	bool found = false;
	TreeNode<ItemType> *del, *t, *parent, *par_successor;

	del = root;   // will be node to delete
	parent = NULL;   // parent of del's node

					 // search for the node with item
	while (!found && del != NULL)
		if (del->info == item)
			found = true;
		else {
			parent = del;
			if (del->info > item)
				del = del->left;
			else
				del = del->right;
		}

		if (!found)
			cout << " NOT in dictionary" << endl;
		else {
			if (del->right == NULL)    // no right child
				t = del->left;     // child of parent will be left child of del node

			else if (del->right->left == NULL) {  // has right child with no left child
				t = del->right;  // right child will be child of parent
				t->left = del->left;
			}
			else {
				// find successor (smallest (leftmost) in right subtree)
				par_successor = del->right;  // will point to parent of successor
				while (par_successor->left->left != NULL)
					par_successor = par_successor->left;
				t = par_successor->left;  // successor of del node
				par_successor->left = t->right;  // splice out successor
				t->left = del->left;
				t->right = del->right;
			}

			if (parent != NULL)
				if (del->info > parent->info)   //parent's left or right child?
					parent->right = t;
				else
					parent->left = t;
			else
				root = t;          //new root node

			delete del;
		}
}



//*********************************************************
template<class ItemType>
void TreeType<ItemType>::PrintTree() const
// Calls Print function to display items in the tree.
{
	Print(root);            //recursive
}


template<class ItemType>
void Print(TreeNode<ItemType>* t)  //t points to a node
								   // Prints info member of items in tree in sorted order to screen
								   //recursive inorder traversal
{
	if (t != NULL) {
		Print(t->left);        // Print left subtree.
		cout << *t;            // print the node t points to.
		Print(t->right);	   // Print right subtree.
	}
}



//*********************************************************
template<class ItemType>
void Destroy(TreeNode<ItemType>* t)    //t points to a node
									   // Post: tree is empty; nodes have been deallocated.
									   //postorder traversal
{
	if (t != NULL) {
		Destroy(t->left);
		Destroy(t->right);
		delete t;
	}
}

//*********************************************************
template<class ItemType>
TreeType<ItemType>::~TreeType()
// Calls recursive function Destroy to destroy the tree.
{
	Destroy(root);
}
