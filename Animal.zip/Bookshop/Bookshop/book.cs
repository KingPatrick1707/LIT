﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookshop
{
    class book
    {
        public string ISBN { get; set; }
        public string Author { get; set; }
        public string Title { get; set; }
        public double Price { get; set; }

        public book (string b, string a, string t, double p)
        {
            this.ISBN = b;
            this.Author = a;
            this.Title = t;
            this.Price = p;
        }

        public void print()
        {
            Console.WriteLine("ISBN: " + this.ISBN);
            Console.WriteLine("Author: " + this.Author);
            Console.WriteLine("Title: " + this.Title);
            Console.WriteLine("Price: " + this.Price);
        }

    }
}
