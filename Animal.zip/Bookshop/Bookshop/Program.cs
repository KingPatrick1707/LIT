﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookshop
{
    class Program
    {
        static void Main(string[] args)
        {
            //two classes 1 main program, 1 book class
            int bookCount = 0;
            

            CBookshop[] bookArray = new CBookshop[25];//int[] studentMarks = new int[5] { 23, 34, 54, 65, 73 };

            int number = 0, counter = 0;
            string userInputISBN, userInputAuther, userInputTitle, tempUserInputPrice;
            double userInputPrice;
            Console.WriteLine("welcome");
            number = Convert.ToInt32(Console.ReadLine());
            do
            {
                switch (number)
                {
                    case 1:

                        {
                            counter++;
                            Console.WriteLine("isbn");
                            userInputISBN = Console.ReadLine();
                            Console.WriteLine("auther");
                            userInputAuther = Console.ReadLine();
                            Console.WriteLine("title");
                            userInputTitle = Console.ReadLine();
                            Console.WriteLine("price");
                            tempUserInputPrice = Console.ReadLine();
                            userInputPrice = Convert.ToDouble(tempUserInputPrice);

                            bookArray[counter] = new CBookshop(userInputISBN, userInputAuther, userInputTitle, userInputPrice);
                            bookCount++;
                            break;
                        }
                    case 2:
                        displayArray(ref bookArray, bookCount);

                        break;
                    case 3:
                        displayArray(ref bookArray, bookCount);
                        break;
                    case 4:
                        break;
                    case 5:
                        break;
                    default:
                        break;
                }

            } while (number != 6);
        }
        public static void displayArray(ref CBookshop[] books, int bookCount)
        {
            for (int i = 0; i < bookCount; i++)
            {
                    books[i].print();
                    //bookArray[i].print();
            }
        }

        public static void searchISBN(ref CBookshop[] books, int bookCount)
        {
            string ISBNInput;
            Console.WriteLine("enter ISBN:\n");
            ISBNInput = Console.ReadLine();

            for (int i = 0; i < bookCount; i++)
            {
                if (books[i].this.ISBN = ISBNInput)
                {
                
                }
                //bookArray[i].print();
            }
        }


    }
}

