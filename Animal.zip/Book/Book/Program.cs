﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Book
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
        Each class should have a suitable set of constructors, accessor functions and appropriate implementor functions

        c)	Write a test application that will
        i.	Instantiate a number of ebook objects with title, ISBN, author, base price,  countryTax, downloadURL and sizeMB.

        ii.	Instantiate a number of paper book objects with title, ISBN, author, base price, countryTax, shipping weight and total in stock.

        iii.	Display a cost list to the user showing title, ISBN and cost for each book

        iv.	Display a list of downloadURLs to the user for all ebooks object display there downloadURLs to the user.
        */

        }
        abstract class Book
        {
            /*A Book has a title, ISBN, author, base price and countryTax
             A Book cost is calculated as follows base price plus % country Tax.*/
            string title { get; set; }
            string ISBN { get; set; }
            string author { get; set; }
            double price { get; set; }
            double countryTax { get; set; }

            Book() { }

            public Book(string t, string i, string a, double p, double c)
            {
                title = t;
                ISBN = i;
                author = a;
                price = p;
                countryTax = c;
            }
            public virtual double CalculateCost()
            {
                return price + countryTax;
            }
            public void printBook()
            {
                Console.Write("title" + title + "ISBN" + ISBN + "author" + author);
            }
            abstract public void print();
        }
        class EBook : Book
        {
            //An EBook has a downloadURL and  sizeMB.
            string downloadURL { get; set; }
            int sizeMB { get; set; }

            public EBook(string t, string i, string a, double p, double c, string d, int s):base(t,  i,  a,  p,  c)
            {
                downloadURL = d;
                sizeMB = s;
            }
            public override double CalculateCost()
            {
                return base.CalculateCost();
            }
            public override void print()
            {
                this.printBook();
                Console.WriteLine("downloadURL: " + downloadURL + "sizeMB: " + sizeMB);
            }
        }
        class paperbook : Book
        {
            double shippingWeight { get; set; }
            int totalInStock { get; set; }
            double countryTax { get; set; }
            double handelingCost { get; set; }
            public paperbook(string t, string i, string a, double p, double c, double s, int ts, double ct, double h) : base(t, i, a, p, c)
            {
                shippingWeight = s;
                totalInStock = ts;
                countryTax = ct;
                handelingCost = h;
            }
            public override double CalculateCost()
            {
                return (base.CalculateCost() % countryTax) + handelingCost;
            }
            /*A PaperBook has a shippingWeight, totalInStock, countryTax and handelingCost.
            A paper book cost is calculated as follows base price plus % country Tax plus handelingCost.*/
        }
    }
}
