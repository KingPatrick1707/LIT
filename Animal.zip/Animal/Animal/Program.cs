﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Animal
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Animal> myAnimals = new List<Animal>();
            test(myAnimals);

        }
        public static void test(List<Animal> l)
        {
            Horse h = new Horse(4, "mike", "ps1234", true);
            l.Add(h);
            Raindear rain = new Raindear(4, "ruby", "ps1235", true);
            l.Add(h);
            Robin rob = new Robin(4, "rob", "ps16", 1.25, true);
            l.Add(h);
        }
        public static void santasHelpers(List<Animal> l)
        {
            foreach (Animal a in l)
            {
                if (a is ISantasHelper)
                {
                    a.print();
                    ISantasHelper sh = (ISantasHelper)a;
                    Console.WriteLine(sh.SpecialPower());
                    Console.WriteLine();
                }
            }
        }   
    }
    abstract class Animal
    {
        int NumberOfLegs { get; set; }
        string Name { get; set; }
        string AnimalPassportNumber { get; set; }

        Animal() { }

        public Animal(int nl, string n, string pn)
        {
            NumberOfLegs = nl;
            Name = n;
            AnimalPassportNumber = pn;
        }
        public void printAnimal()
        {
            Console.Write("Name" + Name + "NumberOfLegs" + NumberOfLegs + "AnimalPassportNumber" + AnimalPassportNumber);
        }
        abstract public void print();
    }
    class Robin : Animal, ISantasHelper
    {
        double wingSpan { get; set; }
        bool Ringed { get; set; }

        public Robin(int nl, string n, string pn, double ws, Boolean r) : base(nl, n, pn)
        {
            wingSpan = ws;
            Ringed = r;
        }
        public String SpecialPower()
        {
            return "I can on kids and let you know if they are good or bad";
        }
        public override void print()
        {
            this.printAnimal();
            Console.WriteLine("wing span: " + wingSpan + "Ringed: " + Ringed);
        }
    }
    class Raindear : Animal, ISantasHelper
    {
        Boolean redNose { get; set; }
        public Raindear(int nl, string n, string pn, Boolean r) : base(nl, n, pn)
        {
            redNose = r;
        }
        public override void print()
        {
            this.printAnimal();
            Console.WriteLine("Red Nose: " + redNose);
        }
        public String SpecialPower()
        {
            return "I can fly and help in guiding the sled";
        }
    }
    class Horse : Animal
    {
        Boolean racing { get; set; }
        public Horse(int nl, string n, string pn, Boolean r) : base(nl, n, pn)
        {
            racing = r;
        }
        public override void print()
        {
            this.printAnimal();
            Console.WriteLine("Racing" + racing);
        }

    }
    interface ISantasHelper
    {
        String SpecialPower();
    }

}
