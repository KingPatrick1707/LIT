﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABC
{
    public abstract class CPackage
    {
        public string SenderName { get; set; }
        public string SenderAddress { get; set; }
        public string SenderCity { get; set; }
        public string SenderState { get; set; }
        public string SenderZIP { get; set; }
        public string RecipientName { get; set; }
        public string RecipientAddress { get; set; }
        public string RecipientCity { get; set; }
        public string RecipientState { get; set; }
        public string RecipientZIP { get; set; }

        public double Weight { get; set; }
        public double Cost { get; set; }

        public string CourierName { get; set; }
        public string CourierAddress { get; set; }
        public string CourierCity { get; set; }
        public string CourierState { get; set; }
        public string CourierZIP { get; set; }

        public CPackage(string sname, string saddress, string scity, string sstate, string szip
            , string rname, string raddress, string rcity, string rstate, string rzip
            ,string cname, string caddress, string ccity, string cstate, string czip,double weight,double cost)
        {
            SenderName = sname;
            SenderAddress = saddress;
            SenderCity = scity;
            SenderState = sstate;
            SenderZIP = szip;
            RecipientName = rname;
            RecipientAddress = raddress;
            RecipientCity = rcity;
            RecipientState = rstate;
            RecipientZIP = rzip;
            CourierName = cname;
            CourierAddress = caddress;
            CourierCity = ccity;
            CourierState = cstate;
            CourierZIP = czip;
            Weight = weight;
            Cost = cost;
        }
        public virtual double CalculateCost()
        {
            if (Weight == 0)
                return Cost;
            else
                return Cost * Weight;
         }
        public abstract double Percentage();
        public abstract string ShowDetails();
        public abstract string ShowCourierDetails();
    }
}
