﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABC
{
    class Program 
    {
        static void Main(string[] args)
        {
            int userInput = 0; string user;
            List<CPackage> Deliverys = new List<CPackage>();
            createInitialAccounts(Deliverys);
            do
            {
                Console.WriteLine(" 1: Create parcels");
                Console.WriteLine(" 2: Display Shipping details");
                Console.WriteLine(" 3: Cost Analysis");
                Console.WriteLine(" 4: Display Couriers details");
                Console.WriteLine(" 5: Exit.");
                user = Console.ReadLine();
                userInput = Convert.ToInt32(user);
                switch (userInput)
                {
                    case 1:
                        createAccounts(Deliverys);
                        break;
                    case 2:
                        displayAccounts(Deliverys);
                        break;
                    case 3:
                        displayPercentage(Deliverys);
                        break;
                    case 4:
                        displayCourierDetails(Deliverys);
                        break;
                    case 5:
                        Console.WriteLine("Program End");
                        userInput = 5;
                        break;
                    default:
                        Console.WriteLine("error program terminated");
                        break;
                }
            } while (userInput != 5);
        }
        public static void createAccounts(List<CPackage> cDeliverys)
        {
            double basicCost, weight;
            string sname, saddress, scity, sstate, szip, rname, raddress, rcity, rstate, rzip,temp, cname, caddress,ccity, cstate,czip;   
            Console.WriteLine("Please enter the Sender's Name(SN)");
            sname = Console.ReadLine();
            Console.WriteLine("Please enter the Sender's Address(SA)");
            saddress = Console.ReadLine();
            Console.WriteLine("Please enter the Sender's home city(SC)");
            scity = Console.ReadLine();
            Console.WriteLine("Please enter the Sender's home state(SS)");
            sstate = Console.ReadLine();
            Console.WriteLine("Please enter the Sender's ZIP code(SZ)");
            szip = Console.ReadLine();
            Console.WriteLine("Please enter the Recipient's Name(RN)");
            rname = Console.ReadLine();
            Console.WriteLine("Please enter the Recipient's Address(RA)");
            raddress = Console.ReadLine();
            Console.WriteLine("Please enter the Recipient's home city(RC)");
            rcity = Console.ReadLine();
            Console.WriteLine("Please enter the Recipient's home state(RS)");
            rstate = Console.ReadLine();
            Console.WriteLine("Please enter the Recipient's ZIP code(RZ)");
            rzip = Console.ReadLine();
            Console.WriteLine("Please enter the package's basic cost");
            basicCost = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Please enter the package's weight");
            weight = Convert.ToDouble(Console.ReadLine());
            if (weight < 0)
            {
                 Console.WriteLine("Error weight cannot be less the zero");
                        
            }
            Console.WriteLine("Please enter 1 for an two day package deal and 2 for an overnight package deal");
            temp = Console.ReadLine();
            if (temp == "1")
                    {
                        CTwoDayPackage TUser = new CTwoDayPackage(sname, saddress, scity, sstate, szip, rname, raddress, rcity, rstate, rzip, null, null, null, null, null, weight, basicCost);
                        cDeliverys.Add(TUser);
                    }
                    else if (temp == "2")
                    {
                        Console.WriteLine("Does this package require a courier?\nPlease enter 1 for yes or 2 for no");
                        temp = Console.ReadLine();
                        if(temp == "2")
                        {
                            COvernightPackage OUser = new COvernightPackage(sname, saddress, scity, sstate, szip, rname, raddress, rcity, rstate, rzip, null, null, null, null, null, weight, basicCost);
                            cDeliverys.Add(OUser);
                        }
                        else if (temp == "1")
                        {
                            Console.WriteLine("Please enter the Couriers's Name(CN)");
                            cname = Console.ReadLine();
                            Console.WriteLine("Please enter the Couriers's Address(CA)");
                            caddress = Console.ReadLine();
                            Console.WriteLine("Please enter the Couriers's home city(CC)");
                            ccity = Console.ReadLine();
                            Console.WriteLine("Please enter the Couriers's home state(CS)");
                            cstate = Console.ReadLine();
                            Console.WriteLine("Please enter the Couriers's ZIP code(CZ)");
                            czip = Console.ReadLine();
                            COvernightPackage CUser = new COvernightPackage(sname, saddress, scity, sstate, szip, rname, raddress, rcity, rstate, rzip, cname, caddress, ccity, cstate, czip, weight, basicCost);
                            cDeliverys.Add(CUser);
                        }
                        else
                        {
                            Console.WriteLine("Error!!! you must select either 1 or 2 for if there is a courier");
                            
                        }
                    }
                    else
                    {
                        Console.WriteLine("Error!!! you must select either 1 or 2 for which deal you want");
                        
                    }   
        }
        public static void displayAccounts(List<CPackage> cDeliverys)
        {
            Console.WriteLine("Please note that (CO) means the package's total cost");
            foreach (CPackage a in cDeliverys)
            {
                string s = a.ShowDetails();
                Console.WriteLine(s); 
            }
        }
        public static void displayPercentage(List<CPackage> cPercentage)
        {
            double total = 0,numO = 0,numT = 0;
            string numOFormated, numTFormated;
            foreach (CPackage a in cPercentage)
            {
                total += a.CalculateCost();
                if (a is CTwoDayPackage)
                {
                    numT += a.CalculateCost();
                }
                if (a is COvernightPackage)
                {
                    numO += a.CalculateCost();
                }
            }
            numT = (numT / total) * 100;
            numO = (numO / total) * 100;
            numTFormated = numT.ToString("n2");
            numOFormated = numO.ToString("n2");
            Console.WriteLine("Total shippment cost is  {0}", total);
            Console.WriteLine("Total two day cost is  {0}", numTFormated);
            Console.WriteLine("Total overnight cost is  {0}", numOFormated);

            
        }
        public static void displayCourierDetails(List<CPackage> cCourierDetails)
        {
            foreach (CPackage a in cCourierDetails)
            {
                string s = a.ShowCourierDetails();
                Console.WriteLine(s);
            }
        }
        public static void createInitialAccounts(List<CPackage> cDeliverys)
        {
            CTwoDayPackage P1 = new CTwoDayPackage("sname", "saddress1", "scity", "sstate", "szip", "rname", "raddress1", "rcity", "rstate", "rzip", null, null, null, null, null, 2, 10);
            CTwoDayPackage P2 = new CTwoDayPackage("sname", "saddress2", "scity", "sstate", "szip", "rname", "raddress2", "rcity", "rstate", "rzip", null, null, null, null, null, 4, 10);
            CTwoDayPackage P3 = new CTwoDayPackage("sname", "saddress3", "scity", "sstate", "szip", "rname", "raddress3", "rcity", "rstate", "rzip", null, null, null, null, null, 6, 10);
            CTwoDayPackage P4 = new CTwoDayPackage("sname", "saddress4", "scity", "sstate", "szip", "rname", "raddress4", "rcity", "rstate", "rzip", null, null, null, null, null, 15, 10);
            cDeliverys.Add(P1);
            cDeliverys.Add(P2);
            cDeliverys.Add(P3);
            cDeliverys.Add(P4);
            COvernightPackage P5 = new COvernightPackage("sname", "saddress5", "scity", "sstate", "szip", "rname", "raddress5", "rcity", "rstate", "rzip", null, null, null, null, null, 4, 15);
            COvernightPackage P6 = new COvernightPackage("sname", "saddress6", "scity", "sstate", "szip", "rname", "saddress6", "rcity", "rstate", "rzip", "cname", "caddress", "ccity", "cstate", "czip", 6, 20);
            COvernightPackage P7 = new COvernightPackage("sname", "saddress7", "scity", "sstate", "szip", "rname", "saddress7", "rcity", "rstate", "rzip", "cname", "caddress", "ccity", "cstate", "czip", 8, 20);
            COvernightPackage P8 = new COvernightPackage("sname", "saddress8", "scity", "sstate", "szip", "rname", "saddress8", "rcity", "rstate", "rzip", "cname", "caddress", "ccity", "cstate", "czip", 10, 20);
            cDeliverys.Add(P5);
            cDeliverys.Add(P6);
            cDeliverys.Add(P7);
            cDeliverys.Add(P8);
        }
    }
}
