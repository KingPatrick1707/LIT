﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABC
{
    class CTwoDayPackage : CPackage
    {
        public double FlatFee = 10, totalCost,percentage;
        public CTwoDayPackage(string sname, string saddress, string scity, string sstate, string szip, 
            string rname, string raddress, string rcity, string rstate, string rzip, 
            string cname, string caddress, string ccity, string cstate, string czip, double weight, double cost) : base(sname, saddress,  scity,sstate, szip,
                rname, raddress,  rcity, rstate, rzip,
                cname, caddress, ccity, cstate, czip, weight,cost)
        {}
        public override double CalculateCost()
        {
            totalCost = base.CalculateCost() + FlatFee;
            return base.CalculateCost() + FlatFee; 
        }
        public override string ShowDetails()
        {
            string costFormated = CalculateCost().ToString("n2");

            return String.Format("\t(SN):{0} \n\t(SA):{1} \n\t(SC):{2} \n\t(SS):{3} \n\t(SZ):{4} " +
                "\n\t(RN):{5} \n\t(RA):{6} \n\t(RC):{7} \n\t(RS):{8} \n\t(RZ):{9} \n\t(CO):{10}"
                , SenderName, SenderAddress, SenderCity, SenderState, SenderZIP,
                RecipientName, RecipientAddress, RecipientCity, RecipientState, RecipientZIP, costFormated + "\n\n");
        }
        public override double Percentage()
        {
            percentage = ((base.CalculateCost() + FlatFee)/ base.CalculateCost()) * 100;
            return base.CalculateCost();
        }
        public override string ShowCourierDetails()
        {
            return null;
        }
    }
}
