﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Form1 : Form
    {
        double resultValue = 0;
        string operationPerformed = "";
        bool isOperationPerformed = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void btm_Click(object sender, EventArgs e)
        {
            if ((txtResult.Text == "0") || (isOperationPerformed))
                txtResult.Clear();
            isOperationPerformed = false;
            Button button = (Button)sender;
            if(button.Text == ".")
            {
                if(!txtResult.Text.Contains("."))
                    txtResult.Text = txtResult.Text + button.Text;
            }
            else
            {
                txtResult.Text = txtResult.Text + button.Text;
            }
                
        }

        private void operator_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            if (resultValue != 0)
            {
                //btmEquals_Click.PerformAutoScale();
                //btmEquals_Click.PerformClick();
                operationPerformed = button.Text;
                resultValue = resultValue + double.Parse(txtResult.Text);
                labelCurrentOperation.Text = labelCurrentOperation.Text + " " + resultValue + " " + operationPerformed;
                isOperationPerformed = true;
            }
            else
            {
                operationPerformed = button.Text;
                resultValue = resultValue + double.Parse(txtResult.Text);
                labelCurrentOperation.Text = resultValue + " " + operationPerformed;
                isOperationPerformed = true;
            }
        }

        private void btmClearEntry_Click(object sender, EventArgs e)
        {
            txtResult.Text = "0";
        }

        private void btmClear_Click(object sender, EventArgs e)
        {
            txtResult.Text = "0";
            resultValue = 0;
            labelCurrentOperation.Text = "";
        }

        private void btmEquals_Click(object sender, EventArgs e)
        {
            switch (operationPerformed)
            {
                case "+":
                    txtResult.Text = (resultValue + double.Parse(txtResult.Text)).ToString();
                    break;
                case "-":
                    txtResult.Text = (resultValue - double.Parse(txtResult.Text)).ToString();
                    break;
                case "*":
                    txtResult.Text = (resultValue * double.Parse(txtResult.Text)).ToString();
                    break;
                case "/":
                    txtResult.Text = (resultValue / double.Parse(txtResult.Text)).ToString();
                    break;
                default:
                    break;
            }
            resultValue = double.Parse(txtResult.Text);
            labelCurrentOperation.Text = "";
        }
    }
}
