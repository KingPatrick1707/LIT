﻿namespace Calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btmSeven = new System.Windows.Forms.Button();
            this.btmEight = new System.Windows.Forms.Button();
            this.btmNine = new System.Windows.Forms.Button();
            this.btmDivide = new System.Windows.Forms.Button();
            this.btmClearEntry = new System.Windows.Forms.Button();
            this.btmFour = new System.Windows.Forms.Button();
            this.btmFive = new System.Windows.Forms.Button();
            this.btmSix = new System.Windows.Forms.Button();
            this.btmMultiply = new System.Windows.Forms.Button();
            this.btmClear = new System.Windows.Forms.Button();
            this.btmOne = new System.Windows.Forms.Button();
            this.btmTwo = new System.Windows.Forms.Button();
            this.btmThree = new System.Windows.Forms.Button();
            this.btmMinus = new System.Windows.Forms.Button();
            this.btmZero = new System.Windows.Forms.Button();
            this.btmDecimalPoint = new System.Windows.Forms.Button();
            this.btmPlus = new System.Windows.Forms.Button();
            this.btmEquals = new System.Windows.Forms.Button();
            this.txtResult = new System.Windows.Forms.TextBox();
            this.labelCurrentOperation = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btmSeven
            // 
            this.btmSeven.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmSeven.Location = new System.Drawing.Point(12, 71);
            this.btmSeven.Name = "btmSeven";
            this.btmSeven.Size = new System.Drawing.Size(45, 45);
            this.btmSeven.TabIndex = 0;
            this.btmSeven.Text = "7";
            this.btmSeven.UseVisualStyleBackColor = true;
            this.btmSeven.Click += new System.EventHandler(this.btm_Click);
            // 
            // btmEight
            // 
            this.btmEight.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmEight.Location = new System.Drawing.Point(63, 71);
            this.btmEight.Name = "btmEight";
            this.btmEight.Size = new System.Drawing.Size(45, 45);
            this.btmEight.TabIndex = 1;
            this.btmEight.Text = "8";
            this.btmEight.UseVisualStyleBackColor = true;
            this.btmEight.Click += new System.EventHandler(this.btm_Click);
            // 
            // btmNine
            // 
            this.btmNine.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmNine.Location = new System.Drawing.Point(114, 71);
            this.btmNine.Name = "btmNine";
            this.btmNine.Size = new System.Drawing.Size(45, 45);
            this.btmNine.TabIndex = 2;
            this.btmNine.Text = "9";
            this.btmNine.UseVisualStyleBackColor = true;
            this.btmNine.Click += new System.EventHandler(this.btm_Click);
            // 
            // btmDivide
            // 
            this.btmDivide.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmDivide.Location = new System.Drawing.Point(165, 71);
            this.btmDivide.Name = "btmDivide";
            this.btmDivide.Size = new System.Drawing.Size(45, 45);
            this.btmDivide.TabIndex = 3;
            this.btmDivide.Text = "/";
            this.btmDivide.UseVisualStyleBackColor = true;
            this.btmDivide.Click += new System.EventHandler(this.operator_Click);
            // 
            // btmClearEntry
            // 
            this.btmClearEntry.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmClearEntry.Location = new System.Drawing.Point(216, 71);
            this.btmClearEntry.Name = "btmClearEntry";
            this.btmClearEntry.Size = new System.Drawing.Size(53, 45);
            this.btmClearEntry.TabIndex = 4;
            this.btmClearEntry.Text = "CE";
            this.btmClearEntry.UseVisualStyleBackColor = true;
            this.btmClearEntry.Click += new System.EventHandler(this.btmClearEntry_Click);
            // 
            // btmFour
            // 
            this.btmFour.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmFour.Location = new System.Drawing.Point(12, 122);
            this.btmFour.Name = "btmFour";
            this.btmFour.Size = new System.Drawing.Size(45, 45);
            this.btmFour.TabIndex = 5;
            this.btmFour.Text = "4";
            this.btmFour.UseVisualStyleBackColor = true;
            this.btmFour.Click += new System.EventHandler(this.btm_Click);
            // 
            // btmFive
            // 
            this.btmFive.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmFive.Location = new System.Drawing.Point(63, 122);
            this.btmFive.Name = "btmFive";
            this.btmFive.Size = new System.Drawing.Size(45, 45);
            this.btmFive.TabIndex = 6;
            this.btmFive.Text = "5";
            this.btmFive.UseVisualStyleBackColor = true;
            this.btmFive.Click += new System.EventHandler(this.btm_Click);
            // 
            // btmSix
            // 
            this.btmSix.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmSix.Location = new System.Drawing.Point(114, 122);
            this.btmSix.Name = "btmSix";
            this.btmSix.Size = new System.Drawing.Size(45, 45);
            this.btmSix.TabIndex = 7;
            this.btmSix.Text = "6";
            this.btmSix.UseVisualStyleBackColor = true;
            this.btmSix.Click += new System.EventHandler(this.btm_Click);
            // 
            // btmMultiply
            // 
            this.btmMultiply.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmMultiply.Location = new System.Drawing.Point(165, 122);
            this.btmMultiply.Name = "btmMultiply";
            this.btmMultiply.Size = new System.Drawing.Size(45, 45);
            this.btmMultiply.TabIndex = 8;
            this.btmMultiply.Text = "*";
            this.btmMultiply.UseVisualStyleBackColor = true;
            this.btmMultiply.Click += new System.EventHandler(this.operator_Click);
            // 
            // btmClear
            // 
            this.btmClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmClear.Location = new System.Drawing.Point(216, 122);
            this.btmClear.Name = "btmClear";
            this.btmClear.Size = new System.Drawing.Size(53, 45);
            this.btmClear.TabIndex = 9;
            this.btmClear.Text = "C";
            this.btmClear.UseVisualStyleBackColor = true;
            this.btmClear.Click += new System.EventHandler(this.btmClear_Click);
            // 
            // btmOne
            // 
            this.btmOne.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmOne.Location = new System.Drawing.Point(12, 173);
            this.btmOne.Name = "btmOne";
            this.btmOne.Size = new System.Drawing.Size(45, 45);
            this.btmOne.TabIndex = 10;
            this.btmOne.Text = "1";
            this.btmOne.UseVisualStyleBackColor = true;
            this.btmOne.Click += new System.EventHandler(this.btm_Click);
            // 
            // btmTwo
            // 
            this.btmTwo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmTwo.Location = new System.Drawing.Point(63, 173);
            this.btmTwo.Name = "btmTwo";
            this.btmTwo.Size = new System.Drawing.Size(45, 45);
            this.btmTwo.TabIndex = 11;
            this.btmTwo.Text = "2";
            this.btmTwo.UseVisualStyleBackColor = true;
            this.btmTwo.Click += new System.EventHandler(this.btm_Click);
            // 
            // btmThree
            // 
            this.btmThree.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmThree.Location = new System.Drawing.Point(114, 173);
            this.btmThree.Name = "btmThree";
            this.btmThree.Size = new System.Drawing.Size(45, 45);
            this.btmThree.TabIndex = 12;
            this.btmThree.Text = "3";
            this.btmThree.UseVisualStyleBackColor = true;
            this.btmThree.Click += new System.EventHandler(this.btm_Click);
            // 
            // btmMinus
            // 
            this.btmMinus.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmMinus.Location = new System.Drawing.Point(165, 173);
            this.btmMinus.Name = "btmMinus";
            this.btmMinus.Size = new System.Drawing.Size(45, 45);
            this.btmMinus.TabIndex = 13;
            this.btmMinus.Text = "-";
            this.btmMinus.UseVisualStyleBackColor = true;
            this.btmMinus.Click += new System.EventHandler(this.operator_Click);
            // 
            // btmZero
            // 
            this.btmZero.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmZero.Location = new System.Drawing.Point(12, 224);
            this.btmZero.Name = "btmZero";
            this.btmZero.Size = new System.Drawing.Size(96, 45);
            this.btmZero.TabIndex = 15;
            this.btmZero.Text = "0";
            this.btmZero.UseVisualStyleBackColor = true;
            this.btmZero.Click += new System.EventHandler(this.btm_Click);
            // 
            // btmDecimalPoint
            // 
            this.btmDecimalPoint.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmDecimalPoint.Location = new System.Drawing.Point(114, 224);
            this.btmDecimalPoint.Name = "btmDecimalPoint";
            this.btmDecimalPoint.Size = new System.Drawing.Size(45, 45);
            this.btmDecimalPoint.TabIndex = 17;
            this.btmDecimalPoint.Text = ".";
            this.btmDecimalPoint.UseVisualStyleBackColor = true;
            this.btmDecimalPoint.Click += new System.EventHandler(this.btm_Click);
            // 
            // btmPlus
            // 
            this.btmPlus.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmPlus.Location = new System.Drawing.Point(165, 224);
            this.btmPlus.Name = "btmPlus";
            this.btmPlus.Size = new System.Drawing.Size(45, 45);
            this.btmPlus.TabIndex = 18;
            this.btmPlus.Text = "+";
            this.btmPlus.UseVisualStyleBackColor = true;
            this.btmPlus.Click += new System.EventHandler(this.operator_Click);
            // 
            // btmEquals
            // 
            this.btmEquals.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmEquals.Location = new System.Drawing.Point(216, 173);
            this.btmEquals.Name = "btmEquals";
            this.btmEquals.Size = new System.Drawing.Size(53, 96);
            this.btmEquals.TabIndex = 19;
            this.btmEquals.Text = "=";
            this.btmEquals.UseVisualStyleBackColor = true;
            this.btmEquals.Click += new System.EventHandler(this.btmEquals_Click);
            // 
            // txtResult
            // 
            this.txtResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtResult.Location = new System.Drawing.Point(12, 36);
            this.txtResult.Name = "txtResult";
            this.txtResult.Size = new System.Drawing.Size(257, 29);
            this.txtResult.TabIndex = 20;
            this.txtResult.Text = "0";
            this.txtResult.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // labelCurrentOperation
            // 
            this.labelCurrentOperation.AutoSize = true;
            this.labelCurrentOperation.BackColor = System.Drawing.SystemColors.Window;
            this.labelCurrentOperation.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCurrentOperation.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.labelCurrentOperation.Location = new System.Drawing.Point(12, 9);
            this.labelCurrentOperation.Name = "labelCurrentOperation";
            this.labelCurrentOperation.Size = new System.Drawing.Size(0, 24);
            this.labelCurrentOperation.TabIndex = 21;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(285, 300);
            this.Controls.Add(this.labelCurrentOperation);
            this.Controls.Add(this.txtResult);
            this.Controls.Add(this.btmEquals);
            this.Controls.Add(this.btmPlus);
            this.Controls.Add(this.btmDecimalPoint);
            this.Controls.Add(this.btmZero);
            this.Controls.Add(this.btmMinus);
            this.Controls.Add(this.btmThree);
            this.Controls.Add(this.btmTwo);
            this.Controls.Add(this.btmOne);
            this.Controls.Add(this.btmClear);
            this.Controls.Add(this.btmMultiply);
            this.Controls.Add(this.btmSix);
            this.Controls.Add(this.btmFive);
            this.Controls.Add(this.btmFour);
            this.Controls.Add(this.btmClearEntry);
            this.Controls.Add(this.btmDivide);
            this.Controls.Add(this.btmNine);
            this.Controls.Add(this.btmEight);
            this.Controls.Add(this.btmSeven);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btmSeven;
        private System.Windows.Forms.Button btmEight;
        private System.Windows.Forms.Button btmNine;
        private System.Windows.Forms.Button btmDivide;
        private System.Windows.Forms.Button btmClearEntry;
        private System.Windows.Forms.Button btmFour;
        private System.Windows.Forms.Button btmFive;
        private System.Windows.Forms.Button btmSix;
        private System.Windows.Forms.Button btmMultiply;
        private System.Windows.Forms.Button btmClear;
        private System.Windows.Forms.Button btmOne;
        private System.Windows.Forms.Button btmTwo;
        private System.Windows.Forms.Button btmThree;
        private System.Windows.Forms.Button btmMinus;
        private System.Windows.Forms.Button btmZero;
        private System.Windows.Forms.Button btmDecimalPoint;
        private System.Windows.Forms.Button btmPlus;
        private System.Windows.Forms.Button btmEquals;
        private System.Windows.Forms.TextBox txtResult;
        private System.Windows.Forms.Label labelCurrentOperation;
    }
}

