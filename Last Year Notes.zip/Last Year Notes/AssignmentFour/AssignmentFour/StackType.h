#pragma once
#include <stddef.h>	
//template <class ItemType>
//struct NodeType
//{
//	ItemType info;
//	NodeType* next;
//};
template <class ItemType>
class StackType
{
public:
	StackType();
	~StackType();
	void Pop(ItemType& item);
	void Push(ItemType newItem);
	bool IsEmpty() const;
private:
	NodeType<ItemType>* topPtr;
};

template<class ItemType>
StackType<ItemType>::StackType()
{
	topPtr = NULL;
}
template <class ItemType>
StackType<ItemType>::~StackType()
{
	NodeType<ItemType>* tempPtr;
	while (topPtr != NULL)
	{
		tempPtr = topPtr;
		topPtr = topPtr->next;
		delete tempPtr;
	}
}
template<class ItemType>
void StackType<ItemType>::Pop(ItemType& item)
{
	NodeType<ItemType>* tempPtr;
	item = topPtr->info;
	tempPtr = topPtr;
	topPtr = topPtr->next;
	delete tempPtr;
}
template <class ItemType>
void StackType<ItemType>::Push(ItemType newItem)
{
	NodeType<ItemType>* location;
	location = new NodeType<ItemType>;
	location->info = newItem;
	location->next = topPtr;
	topPtr = location;
}
template <class ItemType>
bool StackType<ItemType>::IsEmpty() const
{
	return (topPtr == NULL);
}
