#pragma once
#include <stddef.h>		 	// For NULL
#include <iostream>
using namespace std;
template <class ItemType>
struct NodeType
{
	ItemType info;
	NodeType* next;
};

template <class ItemType>
class QueType
{
public:
	QueType();
	~QueType();
	void MakeEmpty();
	void PrintStack();
	void Enqueue(ItemType newItem);
	void Dequeue(ItemType& item);
	bool IsEmpty() const;
private:
	NodeType<ItemType>* qFront;
	NodeType<ItemType>* qRear;

};
template <class ItemType>
QueType<ItemType>::QueType()
{
	qFront = NULL;
	qRear = NULL;
}
template <class ItemType>
QueType<ItemType>::~QueType()
{
	MakeEmpty();
}
template <class ItemType>
void QueType<ItemType>::MakeEmpty()
{
	NodeType<ItemType>* tempPtr;

	while (qFront != NULL)
	{
		tempPtr = qFront;
		qFront = qFront->next;
		delete tempPtr;
	}
	qRear = NULL;
}
template <class ItemType>
void QueType<ItemType>::Enqueue(ItemType newItem)
{
	NodeType<ItemType>* newNode;

	newNode = new NodeType<ItemType>;
	newNode->info = newItem;
	newNode->next = NULL;
	if (qRear == NULL)
		qFront = newNode;
	else
		qRear->next = newNode;
	qRear = newNode;
}
template <class ItemType>
void QueType<ItemType>::Dequeue(ItemType& item)
{
	NodeType<ItemType>* tempPtr;

	tempPtr = qFront;
	item = qFront->info;
	qFront = qFront->next;
	if (qFront == NULL)
		qRear = NULL;
	cout << tempPtr->info << endl;
	delete tempPtr;
}
template <class ItemType>
void QueType<ItemType>::PrintStack()
{
	NodeType<ItemType>* tempPtr;
	tempPtr = qFront;
	while (tempPtr != NULL)
	{
		cout << tempPtr->info << endl;
		tempPtr = tempPtr->next;
	}
}
template <class ItemType>
bool QueType<ItemType>::IsEmpty() const
{
	return (qFront == NULL);
}
bool DoQuit(bool& quit)
{
	cout << "******************************************************************************************************\n\n";
	cout << "\tYou have exited the program\n\n";
	cout << "******************************************************************************************************\n\n";
	return quit = true;
}
void mainMenu()
{
	cout << "Please enter a number from the menu\n";
	cout << "1) clear a queue of its contents\n";//makeEmpty()
	cout << "2) add data to the input end of the queue,\n";//Enqueue()
	cout << "3) remove data from the output end of the queue and print each value as it is removed,\n";//Dequeue()
	cout << "4) print the contents of the queue,\n";//PrintStack()
	cout << "5) reverse the data inside the queue\n";
	cout << "6) exit from the application\n";
}


