// Assignment5.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "iostream"
#include "TreeType.h"
#include "Person.h"
using namespace std;
void mainMenu();
bool DoQuit(bool& quit);
bool Found = false;
int main()
{
	TreeType<string> myTree;
	string fname, sname, pnum;
	int input = 0;
	bool quit = false;
	do
	{
		mainMenu();
		cin >> input;
		cout << "\nYou have selected option (" << input << ")" << endl;
		switch (input)
		{
		case 1:
			myTree.MakeEmpty();
			if (myTree.IsEmpty())
			{
				cout << "The tree is empty";
			}
			else
				cout << "error";
			break;
		case 2:
			
			cout << "please enter a first name";
			cin >> fname;
			cout << "please enter a surname";
			cin >> sname;
			cout << "please enter the phone Number";
			cin >> pnum;
			myTree.InsertItem(fname, sname, pnum);
			break;
		case 3:
			cout << "please enter a first name";
			cin >> fname;
			cout << "please enter a surname";
			cin >> sname;
			cout << "please enter the phone Number";
			cin >> pnum;
			myTree.DeleteItem(fname, sname, pnum);
			break;
		case 4:
			cout << "please enter a letter";
			//cin >> letter;
			break;
		case 5:
			cout << "please enter a surname";
			//cin >> data.surname;
			//if(data.surname =)
			//tempData = data.surname;
			//myTree.RetrieveItem(data.surname, Found);
			break;
		case 6:
			DoQuit(quit);
			break;

		}
	} while (input != 6);

	return 0;
}

