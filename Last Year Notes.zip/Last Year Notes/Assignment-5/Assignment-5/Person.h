#pragma once
#include "string"
#include "iostream"
using namespace std;
class Person
{
private:
	string firstName;
	int phonenumber;
	string surname;
public:
	Person();
	Person(string firstName, string surname, int phonenumber);
	string getFirstName();
	string getSurname();
	int getPhonenumber();
	void setFirstName(string newFirstName);
	void setPhonenumber(int newphonenumber);
	void setSurname(string newSurname);


//public:
//	Person();
//	~Person();
};
Person::Person()
{
}
Person::Person(string newFirstName, string newSurname, int newphonenumber)
{
	firstName = newFirstName;
	phonenumber = newphonenumber;
	surname = newSurname;
}
string Person::getFirstName() {
	return firstName;
}
int Person::getPhonenumber() {
	return phonenumber;
}
string Person::getSurname() {
	return surname;
}
void Person::setFirstName(string newFirstName) {
	firstName = newFirstName;
}
void Person::setPhonenumber(int newphonenumber) {
	phonenumber = newphonenumber;
}
void Person::setSurname(string newSurname) {
	surname = newSurname;
}