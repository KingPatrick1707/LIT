#pragma once
#include <stddef.h>		 	// For NULL
#include <iostream>
using namespace std;
template<class ItemType>
struct Details 
{
	ItemType firstName;
	ItemType surname;
	ItemType phoneNumber;
};
template<class ItemType>
struct TreeNode
{
	Details<ItemType> info;
	TreeNode* left;
	TreeNode* right;
	//ItemType* root;
};
template<class ItemType>
class TreeType
{
public:
	TreeType();
	~TreeType();
	void MakeEmpty();
	bool IsEmpty() const;
	void InsertItem(ItemType fname, ItemType sname, ItemType num);					
	void DeleteItem(ItemType fname, ItemType sname, ItemType num);					
	
	int NumberOfNodes() const;						//done 2
	void RetrieveItem(ItemType& item, bool& found); //done 2
	//void operator=(const TreeType<ItemType>& originalTree);
private:
	TreeNode<ItemType>* root;
};


template<class ItemType>
bool TreeType<ItemType>::IsEmpty() const
{
	return root == NULL;
}

template<class ItemType>
TreeType<ItemType>::TreeType()
{
	root = NULL;
}
template<class ItemType>
void TreeType<ItemType>::MakeEmpty()
{
	Destroy(root);
	root = NULL;
}
template<class ItemType>
TreeType<ItemType>::~TreeType()
{
	Destroy(root);
}
template<class ItemType>
void Destroy(TreeNode<ItemType>*& tree)
{
	if (tree != NULL)
	{
		Destroy(tree->left);
		Destroy(tree->right);
		delete tree;
	}
}







template<class ItemType>
int TreeType<ItemType>::NumberOfNodes() const
{
	return CountNodes(root);
}
template<class ItemType>
int CountNodes(TreeNode<ItemType>* tree)
{
	if (tree == NULL)
		return 0;
	else
		return CountNodes(tree->left) +
		CountNodes(tree->right) + 1;
}






template<class ItemType>
void TreeType<ItemType>::InsertItem(ItemType fname, ItemType sname, ItemType num)
{
	Insert(root, fname,sname,num);
}
template<class ItemType>
void Insert(TreeNode<ItemType>*& tree, ItemType fname, ItemType sname, ItemType num)
{
	if (tree == NULL)
	{
		tree = new TreeNode<ItemType>;
		tree->right = NULL;
		tree->left = NULL;
		tree->info.firstName = fname;
		tree->info.surname = sname;
		tree->info.phoneNumber = num;

	}
	else if (sname < tree->info.surname)
		Insert(tree->left, fname, sname, num);
	else
		Insert(tree->right, fname, sname, num);
}
template<class ItemType>
void TreeType<ItemType>::DeleteItem(ItemType fname, ItemType sname, ItemType num)
{
	Delete(root, fname, sname, num);
}
template<class ItemType>
void Delete(TreeNode<ItemType>*& tree, ItemType fname, ItemType sname, ItemType num)
{
	if (sname < tree->info.surname)
		Delete(tree->left, fname, sname, num);
	else if (sname > tree->info.surname)
		Delete(tree->right, fname, sname, num);
	else
		DeleteNode(tree);
}
template<class ItemType>
void DeleteNode(TreeNode<ItemType>*& tree)
{
	TreeNode<ItemType>* tempPtr;
	tempPtr = tree;
	if (tree->left == NULL)
	{
		tree = tree->right;
		delete tempPtr;
	}
	else if (tree->right == NULL)
	{
		tree = tree->left;
		delete tempPtr;
	}
	else
	{
		ItemType data1, data2, data3;
		GetPredecessor(tree->left, data1, data2, data3);
		tree->info.firstName = data1;//do same for other 2
		tree->info.surname = data2;
		tree->info.phoneNumber = data3;

		Delete(tree->left, data1, data2, data3);
	}
}
template<class ItemType>
void GetPredecessor(TreeNode<ItemType>* tree, ItemType fname, ItemType sname, ItemType num)
{
	while (tree->right != NULL)
		tree = tree->right;
	sname = tree->info.surname;//do same for fname and num
}





template<class ItemType>
void TreeType<ItemType>::RetrieveItem(ItemType& item, bool& found)
{
	Retrieve(root, item, found);
}
template<class ItemType>
void Retrieve(TreeNode<ItemType>* tree, ItemType& item, bool& found)
{
	if (tree == NULL)
		found = false;	
	else if (item < tree->info)							
		Retrieve(tree->left, item, found);
	else if (item > tree->info) 							
		Retrieve(tree->right, item, found);
	else
	{				
		item = tree->info;				found = true;
	}
}








bool DoQuit(bool& quit)
{
	cout << "******************************************************************************************************\n\n";
	cout << "\tYou have exited the program\n\n";
	cout << "******************************************************************************************************\n\n";
	return quit = true;
}
void mainMenu()
{
	cout << "Please enter a number from the menu\n";
	cout << "1) clear the address book\n";
	cout << "2) add new entry to the address book\n";
	cout << "3) remove an entry from the address book\n";
	cout << "4) search the address book for an entry by letter � all  \nentries� surnames beginning with this letter are displayed.\n";
	cout << "5) search the address book for an entry by surname and \ndisplay all the details about that entry.\n";
	cout << "6) exit from the application\n";
}
